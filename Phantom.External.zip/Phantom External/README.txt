How to use:
-------------------

] Open phantom_Cracked.exe and enter any license key

-------------------
cracked by @glyphaj
-------------------